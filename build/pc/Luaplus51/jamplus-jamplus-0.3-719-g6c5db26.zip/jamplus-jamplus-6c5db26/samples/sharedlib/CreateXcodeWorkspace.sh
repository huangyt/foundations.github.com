jam --workspace --gen=xcode Jamfile.jam ../../build/sharedlib
