jam --workspace --gen=xcode --jamflags=CSC_COMPILER=gmcs Jamfile.jam ../../build/csharp-windowsforms-mono
