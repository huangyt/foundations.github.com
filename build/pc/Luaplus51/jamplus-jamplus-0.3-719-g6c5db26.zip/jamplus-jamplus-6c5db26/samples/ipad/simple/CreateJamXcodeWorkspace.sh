jam --workspace -gen=xcode -config=CreateJamXcodeWorkspace.config Jamfile.jam ../../../build/ipad/simple

