#include <CoreFoundation/CoreFoundation.h>

int main (int argc, const char * argv[]) {
    // insert code here...
    CFShow(CFSTR("Hello, World!\n"));
    return 0;
}
