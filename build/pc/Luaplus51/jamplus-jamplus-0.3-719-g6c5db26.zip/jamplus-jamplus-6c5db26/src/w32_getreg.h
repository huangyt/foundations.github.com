#ifndef W32_GETREG_H
#define W32_GETREG_H

const char* w32_getreg(LIST* pathlist);
const char* w32_getreg64(LIST* pathlist);

#endif
