SCRIPT_PATH=`dirname $0`
$SCRIPT_PATH/lua/lua $SCRIPT_PATH/../scripts/JamToWorkspace.lua $*
