#ifndef W32_SHORTNAME_H
#define W32_SHORTNAME_H

const char* w32_shortname(LIST* pathlist);

#endif
