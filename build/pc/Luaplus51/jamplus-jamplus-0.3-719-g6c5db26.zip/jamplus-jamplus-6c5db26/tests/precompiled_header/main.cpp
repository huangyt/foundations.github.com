#include <stdio.h>

int main()
{
	printf("%d\n", USEFUL_DEFINE);
	return 0;
}
