#ifndef MYPCH_H
#define MYPCH_H

#include "usefuldefine.h"

#endif
