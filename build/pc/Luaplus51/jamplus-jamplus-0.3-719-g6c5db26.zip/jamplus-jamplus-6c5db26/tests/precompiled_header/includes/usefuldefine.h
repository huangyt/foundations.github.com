#ifndef USEFULDEFINE_H
#define USEFULDEFINE_H

#define USEFUL_DEFINE 10

#endif
