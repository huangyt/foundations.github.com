function Test()
	local pattern = [[
**I** **like** **peas.**
No splits here
]]

	TestPattern(pattern, RunJam{})
end

