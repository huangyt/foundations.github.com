#include <stdio.h>

void Func()
{
	printf("DEBUG: What's up?!\n");
}
