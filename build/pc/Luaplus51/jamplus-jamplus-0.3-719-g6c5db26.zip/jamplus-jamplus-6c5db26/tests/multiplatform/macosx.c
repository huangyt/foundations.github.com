#include <stdio.h>

void MacOSX()
{
	printf("This is a Mac OS X build.\n");
}

