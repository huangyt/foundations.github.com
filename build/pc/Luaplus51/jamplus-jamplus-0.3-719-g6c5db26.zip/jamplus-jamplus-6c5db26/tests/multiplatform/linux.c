#include <stdio.h>

void Linux()
{
	printf("This is a Linux build.\n");
}

