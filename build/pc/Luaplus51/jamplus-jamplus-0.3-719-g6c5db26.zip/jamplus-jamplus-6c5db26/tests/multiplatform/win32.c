#include <stdio.h>

void Win32()
{
	printf("This is a Win32 build.\n");
}

