#include <stdio.h>

void Func()
{
	printf("RELEASE: What's up?!\n");
}
