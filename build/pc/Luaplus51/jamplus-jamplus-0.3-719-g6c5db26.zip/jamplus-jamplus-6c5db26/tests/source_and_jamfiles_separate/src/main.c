#include "precomp.h"

extern int main2();

int main()
{
	printf("Hello!\n");
	main2();
	return 0;
}
