#ifndef PRECOMP_H
#define PRECOMP_H

#include <stdio.h>

#endif // PRECOMP_H
