#include "precomp.h"

int main2()
{
	printf("Hello2!\n");
	return 0;
}
