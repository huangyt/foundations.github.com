#include <stdio.h>

extern void Print();

int main()
{
	printf("Hello, world!\n");
	Print();
	return 0;
}
