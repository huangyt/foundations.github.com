function Test()
	local pattern = [[
ab ad be cd be f0 12
ab cd f0 12
]]

	TestPattern(pattern, RunJam())
end

