#include "generated.h"
#include "main.h"

int main()
{
	Print("Hello");
}
