#include <stdio.h>

int main()
{
	printf("appA\n");
	return 0;
}
