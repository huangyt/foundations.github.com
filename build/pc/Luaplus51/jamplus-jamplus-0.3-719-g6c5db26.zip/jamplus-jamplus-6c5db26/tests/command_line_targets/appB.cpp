#include <stdio.h>

int main()
{
	printf("appB\n");
	return 0;
}
