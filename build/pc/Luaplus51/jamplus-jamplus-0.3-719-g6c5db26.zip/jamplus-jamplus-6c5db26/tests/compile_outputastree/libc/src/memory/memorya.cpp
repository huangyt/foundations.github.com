void memorya()
{
}
