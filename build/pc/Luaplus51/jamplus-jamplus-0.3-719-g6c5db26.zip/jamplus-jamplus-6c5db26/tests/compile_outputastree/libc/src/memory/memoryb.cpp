void memoryb()
{
}

