void LibA()
{
	Print("test libA\n");
}
