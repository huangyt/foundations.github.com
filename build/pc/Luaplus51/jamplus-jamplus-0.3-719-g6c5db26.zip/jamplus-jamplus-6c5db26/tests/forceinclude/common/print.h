extern void Print(const char* str);
