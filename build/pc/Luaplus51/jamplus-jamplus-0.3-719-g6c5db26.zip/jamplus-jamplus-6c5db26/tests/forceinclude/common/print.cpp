#include <stdio.h>

void Print(const char* str)
{
	puts(str);
}
