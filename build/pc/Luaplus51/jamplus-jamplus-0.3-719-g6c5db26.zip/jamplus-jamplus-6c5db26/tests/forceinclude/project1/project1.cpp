int main()
{
	Print("This is project1.\n");
	return 0;
}
