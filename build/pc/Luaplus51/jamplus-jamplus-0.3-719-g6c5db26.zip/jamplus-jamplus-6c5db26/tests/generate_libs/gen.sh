../../bin/macosxx86/lua/lua generate_libs.lua gen 50 100 15 5
