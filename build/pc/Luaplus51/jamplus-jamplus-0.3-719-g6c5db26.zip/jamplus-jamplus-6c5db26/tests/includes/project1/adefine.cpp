#include <stdio.h>
#include "adefine.h"

void PrintADefine()
{
	printf("%s\n", THE_STRING);
}
