#include "test.h"

int main()
{
	Print("Hello");
}
