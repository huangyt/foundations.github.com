#include <stdio.h>

void Print(const char* str)
{
	printf("%s\n", str);
}

