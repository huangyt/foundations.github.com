#ifndef CIRCULARA_H_INCLUDED
#define CIRCULARA_H_INCLUDED
#include "circularB.h"
#include "generated.h"
int CIRCULARA_H;
#endif
