#ifndef CIRCULARB_H_INCLUDED
#define CIRCULARB_H_INCLUDED
#include "circularA.h"
int CIRCULARB_H;
#endif
