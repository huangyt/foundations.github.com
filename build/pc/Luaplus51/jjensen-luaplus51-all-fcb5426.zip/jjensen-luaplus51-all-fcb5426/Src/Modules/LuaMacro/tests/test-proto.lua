require_ "proto"

SF_ bonzo.dog (a: int, b: string) : string
