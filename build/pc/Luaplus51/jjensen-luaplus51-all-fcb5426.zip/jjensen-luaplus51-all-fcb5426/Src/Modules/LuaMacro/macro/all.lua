require 'macro.forall'
require 'macro.lambda'
require 'macro.try'
require 'macro.do'

