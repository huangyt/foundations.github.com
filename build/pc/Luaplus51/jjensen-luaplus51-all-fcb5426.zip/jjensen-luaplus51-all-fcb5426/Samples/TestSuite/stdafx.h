#pragma once

#include <stdio.h>

#include "LuaPlus/LuaPlus.h"
using namespace LuaPlus;

