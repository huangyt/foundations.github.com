// -*- mode:C++; tab-width:2; c-basic-offset:2; indent-tabs-mode:nil -*- 
//
// Copyright (C) 2000-2005 by Roger Rene Kommer / artefaktur, Kassel, Germany.
// ALL RIGHTS RESERVED
// 
// This file is part of ACDK.
// artefaktur provides this software "as is" without express or implied warranty.
// Any commercial use of this software requires a license.
// 

#ifndef acdk_aal_aal_h
#define acdk_aal_aal_h


namespace acdk {
/**
  Parser/Compiler for the Artefaktur Aspect Language
*/
namespace aal {


}
}

#endif //acdk_aal_aal_h
