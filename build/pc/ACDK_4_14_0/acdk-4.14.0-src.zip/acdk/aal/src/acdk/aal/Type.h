// -*- mode:C++; tab-width:2; c-basic-offset:2; indent-tabs-mode:nil -*- 
//
// Copyright (C) 2000-2005 by Roger Rene Kommer / artefaktur, Kassel, Germany.
// ALL RIGHTS RESERVED
// 
// This file is part of ACDK.
// artefaktur provides this software "as is" without express or implied warranty.
// Any commercial use of this software requires a license.
// 

#ifndef acdk_aal_Type_h
#define acdk_aal_Type_h


#include "../aci/Code.h"


namespace acdk {
namespace aal {
/* not used
using acdk::lang::dmi::ScriptVar;

ACDK_DECL_CLASS(Type);

class ACDK_AAL_PUBLIC Type
: extends acdk::lang::Object
{
public:
  ScriptVar _sv;
  RCode _definition;

  Type(IN(RCode) def = Nil)  
  : _sv()
  , _definition(def)
  {
  }
  Type(const ScriptVar sv) 
  : _sv(sv)
  {
  }
};
*/
} // aal
} // acdk


#endif //acdk_aal_Type_h
