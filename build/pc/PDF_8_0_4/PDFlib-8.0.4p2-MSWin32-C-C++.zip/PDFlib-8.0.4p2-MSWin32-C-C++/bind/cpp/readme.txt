Notes on the PDFlib C++ binding
-------------------------------

Supported compiler/linker versions for all supported platforms are
listed in system-requirements.txt. This document also lists additional
libraries which may be required for linking PDFlib applications on some
platforms.


Borland C/C++ Edition
---------------------
(See bind/c/readme.txt for information on using PDFlib with BCC.)
